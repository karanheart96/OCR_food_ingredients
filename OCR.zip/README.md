# SmartFoods
If you like this app please click star to support.!!!
This app is an Android OCR to scan food ingredients and covert them in didgital form.It scans the packed food and tells various things about it.We have added an allergy section that helps to identify the ingredients used are not harming the users in any way possible. 

## Introduction
This is the short preview on how the app works.<br>
<b>Home Screen</b><br>
<br>
![Home Screen](/sc.jpg)
<br>
<br>
This is the home screen containing two buttons.
<br>
<br>
![Preferences](/screen1.jpg)
<br>
<br>
This Page consist of list of allergy and things to be avoided for the users.!!<br>
<br>

![GitHub Logo](/screen2.jpg)
<br>
This page consists of camera button for OCR Reading.We have added text to speech conversion for convinence!!




